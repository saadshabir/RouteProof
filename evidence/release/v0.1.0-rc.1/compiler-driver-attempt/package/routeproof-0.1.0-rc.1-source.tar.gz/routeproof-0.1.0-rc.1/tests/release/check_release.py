#!/usr/bin/env python3
"""Protect package integrity and the demo's expected-failure contract."""
import copy
import hashlib
import io
import json
import sys
import tempfile
import tarfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tools/release'))
from package import check, create
from demo import check_result, run

BINARY = Path(sys.argv.pop(1)).resolve()


class ReleaseTests(unittest.TestCase):
    def test_package_is_deterministic_and_detects_tampering(self):
        with tempfile.TemporaryDirectory(prefix='release spaces ') as name:
            tmp = Path(name)
            source = tmp / 'source'
            source.mkdir()
            (source / 'CMakeLists.txt').write_text('project(RouteProof VERSION 0.1.0)\n')
            for folder in ('src', 'build', 'results', 'evidence/release', 'tools/__pycache__'):
                path = source / folder
                path.mkdir(parents=True)
                (path / 'file.txt').write_text(folder)
            a = create(source, tmp / 'a', '0.1.0-rc.1')
            b = create(source, tmp / 'b', '0.1.0-rc.1')
            self.assertEqual(a['archive_sha256'], b['archive_sha256'])
            self.assertEqual(set(a['source_files']), {'CMakeLists.txt', 'src/file.txt'})
            self.assertEqual(check(tmp / 'a')['status'], 'pass')
            archive = tmp / 'a' / a['archive']
            archive.write_bytes(archive.read_bytes() + b'altered')
            with self.assertRaisesRegex(ValueError, 'checksum mismatch'):
                check(tmp / 'a')
            manifest = tmp / 'b/manifest.json'
            value = json.loads(manifest.read_text())
            value['source_files']['src/file.txt'] = '0' * 64
            manifest.write_text(json.dumps(value))
            with self.assertRaisesRegex(ValueError, 'file hashes mismatch'):
                check(tmp / 'b')

    def test_package_refuses_final_version_symlink_and_overwrite(self):
        with tempfile.TemporaryDirectory() as name:
            tmp = Path(name)
            source = tmp / 'source'
            (source / 'src').mkdir(parents=True)
            (source / 'CMakeLists.txt').write_text('project(RouteProof VERSION 0.1.0)\n')
            with self.assertRaises(ValueError):
                create(source, tmp / 'final', '0.1.0')
            (source / 'src/link').symlink_to(source / 'CMakeLists.txt')
            with self.assertRaisesRegex(ValueError, 'symlinks'):
                create(source, tmp / 'linked', '0.1.0-rc.1')
            with self.assertRaises(FileExistsError):
                create(source, tmp / 'linked', '0.1.0-rc.1')

    def test_checker_rejects_unsafe_and_duplicate_archive_entries(self):
        with tempfile.TemporaryDirectory() as name:
            tmp = Path(name)
            source = tmp / 'source'
            source.mkdir()
            (source / 'CMakeLists.txt').write_text('project(RouteProof VERSION 0.1.0)\n')
            for index, names in enumerate((['routeproof-0.1.0-rc.1/../escape'],
                                           ['routeproof-0.1.0-rc.1/duplicate'] * 2)):
                out = tmp / str(index)
                manifest = create(source, out, '0.1.0-rc.1')
                archive = out / manifest['archive']
                with tarfile.open(archive, 'w:gz') as tar:
                    for entry in names:
                        info = tarfile.TarInfo(entry)
                        info.size = 1
                        tar.addfile(info, io.BytesIO(b'x'))
                manifest['archive_sha256'] = hashlib.sha256(archive.read_bytes()).hexdigest()
                (out / 'manifest.json').write_text(json.dumps(manifest))
                with self.assertRaisesRegex(ValueError, 'unsafe or duplicate'):
                    check(out)

    def test_demo_checks_failures_restoration_and_repeat_bytes(self):
        with tempfile.TemporaryDirectory() as name:
            out = Path(name) / 'diamond'
            report = run(BINARY, out)
            self.assertEqual(report['status'], 'pass')
            result = json.loads((out / 'first/result.json').read_text())
            for edit in (lambda x: x.update(status='pass'),
                         lambda x: x['assertions'][2].update(status='pass'),
                         lambda x: x['snapshots'][-1]['administratively_up_links'].append('cd'),
                         lambda x: x['snapshots'][0]['routes'][0]['next_hops'].pop()):
                bad = copy.deepcopy(result)
                edit(bad)
                with self.assertRaises(ValueError):
                    check_result(bad)


if __name__ == '__main__':
    unittest.main()
