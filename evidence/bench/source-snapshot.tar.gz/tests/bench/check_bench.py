#!/usr/bin/env python3
"""Benchmark contracts: semantics, frozen dimensions, raw evidence and limits."""
import copy
import json
import os
import signal
import time
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tools/bench'))
from generate import Random, generate, read_json
from run import execute, run_child, validate_profile
from compare_runs import compare, validate_run

BINARY = str(Path(sys.argv.pop(1)).resolve())
PROFILE = read_json(ROOT / 'benchmarks/profiles/sparse-small.json')


class BenchTests(unittest.TestCase):
    def test_instrumentation_preserves_canonical_bytes_and_actual_counters(self):
        with tempfile.TemporaryDirectory(prefix='bench spaces ') as name:
            tmp = Path(name)
            for index, path in enumerate([ROOT / 'examples/diamond-failures.yaml',
                    ROOT / 'examples/replay/parallel-restoration.json',
                    ROOT / 'examples/replay/initial-down-restoration.json']):
                outputs = []
                for mode in ('simulate', 'bench-sample'):
                    out = tmp / f'{index}-{mode}'
                    proc = subprocess.run([BINARY, mode, str(path), '--out', str(out)], capture_output=True)
                    self.assertIn(proc.returncode, (0, 1), proc.stderr)
                    outputs.append((out / 'result.json').read_bytes())
                self.assertEqual(*outputs)
                result = json.loads(outputs[0])
                sample = json.loads((out / 'sample.json').read_text())
                self.assertEqual(sample['result_sha256'], result['canonical_sha256'])
                self.assertEqual(sample['core_processing_ns'], sum(x['processing_ns'] for x in sample['snapshots']))
                self.assertLessEqual(sample['core_processing_ns'], sample['simulation_ns'])
                self.assertEqual(len(sample['snapshots']), len(result['snapshots']))
                for measured, snapshot in zip(sample['snapshots'], result['snapshots']):
                    self.assertEqual(measured['route_entries'], len(snapshot['routes']))
                    self.assertEqual(measured['next_hop_references'], sum(len(x['next_hops']) for x in snapshot['routes']))
                    assertions = [x for x in result['assertions'] if x['snapshot_id'] == snapshot['id']]
                    self.assertEqual(measured['assertion_evaluations'], len(assertions))
                    self.assertEqual(measured['failed_assertions'], sum(x['status'] == 'fail' for x in assertions))
                    self.assertGreater(measured['processing_ns'], 0)

    def test_frozen_shapes_coverage_and_trace(self):
        rng = Random(1)
        self.assertEqual([rng.next() for _ in range(3)], [270369, 67634689, 2647435461])
        with tempfile.TemporaryDirectory() as name:
            for shape in ('chain', 'ring', 'grid', 'diamond_ladder', 'sparse_random'):
                cell = dict(PROFILE['cells'][0], shape=shape, prefix_origins='all', assertions='all')
                scenario = generate(cell)
                self.assertEqual(len(scenario['routers']), 16)
                self.assertEqual(len(scenario['prefixes']), 16)
                self.assertEqual(len(scenario['assertions']), 256)
                self.assertEqual(len(scenario['events']), 8)
                self.assertEqual(scenario, generate(cell))
                path = Path(name) / 'scenario.json'
                path.write_text(json.dumps(scenario))
                out = Path(name) / shape
                proc = subprocess.run([BINARY, 'bench-sample', str(path), '--out', str(out)], capture_output=True)
                self.assertEqual(proc.returncode, 1, proc.stderr)
                data = json.loads((out / 'sample.json').read_text())
                self.assertEqual(data['snapshots'][0]['failed_assertions'], 0)
                self.assertEqual(data['snapshots'][-1]['failed_assertions'], 0)
                self.assertEqual(sum(x['applied'] for x in data['snapshots']), 6)
                self.assertEqual(data['analyzed_destinations'], 16)
                result = json.loads((out / 'result.json').read_text())
                kinds = {f['kind'] for a in result['assertions'] for f in a['findings']}
                self.assertTrue({'source_down', 'destination_down', 'no_route'} <= kinds)

    def test_profile_validation_and_duplicate_keys(self):
        for edit in (lambda x: x.update(repetitions=4), lambda x: x.update(schema_version=True),
                     lambda x: x['cells'][0].update(routers=True),
                     lambda x: x['cells'][0].update(unknown=True),
                     lambda x: x['cells'][0].update(routers=4096, assertions='all', prefix_origins='all'),
                     lambda x: x['cells'].append(copy.deepcopy(x['cells'][0]))):
            bad = copy.deepcopy(PROFILE)
            edit(bad)
            with self.assertRaises(ValueError):
                validate_profile(bad)
        with tempfile.TemporaryDirectory() as name:
            path = Path(name) / 'bad.json'
            path.write_text('{"schema_version":1,"schema_version":2}')
            with self.assertRaises(ValueError):
                read_json(path)

    def test_timeout_and_nonzero_exit_preserve_process_artifacts(self):
        with tempfile.TemporaryDirectory() as name:
            tmp = Path(name)
            result = run_child([sys.executable, '-c', 'import time; time.sleep(10)'], tmp / 'timeout', 0.1, 1024**3)
            self.assertEqual(result['status'], 'timeout')
            self.assertTrue((tmp / 'timeout/process.json').exists())
            with self.assertRaises(ProcessLookupError):
                # A terminated child was reaped; no owned sleeper survives.
                os.kill(result['pid'], 0)
            result = run_child([sys.executable, '-c', 'raise SystemExit(3)'], tmp / 'error', 5, 1024**3)
            self.assertEqual(result['status'], 'incomplete')
            self.assertEqual(result['exit_code'], 3)
            result = run_child([sys.executable, '-c', 'x=bytearray(20000000)'], tmp / 'memory', 5, 1024)
            self.assertEqual(result['status'], 'memory_limit')

    def test_interrupt_checkpoints_and_reaps_owned_worker(self):
        with tempfile.TemporaryDirectory() as name:
            tmp = Path(name)
            marker = tmp / 'worker.pid'
            fake = tmp / 'fake.py'
            fake.write_text('#!/usr/bin/env python3\nimport sys,os,time\n'
                'if sys.argv[1] == "validate":\n print("{}")\nelse:\n'
                f' open({str(marker)!r}, "w").write(str(os.getpid()))\n time.sleep(30)\n')
            fake.chmod(0o755)
            profile = tmp / 'profile.json'
            profile.write_text(json.dumps(PROFILE))
            process = subprocess.Popen([sys.executable, str(ROOT / 'tools/bench/run.py'),
                '--binary', str(fake), '--profile', str(profile), '--out', str(tmp / 'out'), '--allow-debug'],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
            try:
                deadline = time.monotonic() + 8
                while not marker.exists() and time.monotonic() < deadline:
                    time.sleep(0.02)
                self.assertTrue(marker.exists())
                os.kill(process.pid, signal.SIGTERM)
                _, stderr = process.communicate(timeout=5)
                self.assertEqual(process.returncode, 3, stderr)
                summary = json.loads((tmp / 'out/summary.json').read_text())
                self.assertEqual(summary['cells'][0]['status'], 'interrupted')
                self.assertEqual(summary['cells'][0]['warmups'][0]['process']['status'], 'interrupted')
                with self.assertRaises(ProcessLookupError):
                    os.kill(int(marker.read_text()), 0)
            finally:
                if process.poll() is None:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()

    def test_harness_fresh_processes_hashes_and_budget_skips(self):
        with tempfile.TemporaryDirectory() as name:
            profile = copy.deepcopy(PROFILE)
            profile['cells'].append(dict(profile['cells'][0], id='budget-probe', routers=1024))
            out = Path(name) / 'evidence'
            self.assertEqual(execute(profile, Path(BINARY), out, allow_debug=True), 3)
            summary = json.loads((out / 'summary.json').read_text())
            self.assertEqual([x['status'] for x in summary['cells']], ['complete', 'budget_skipped'])
            cell = summary['cells'][0]
            self.assertEqual(len(cell['samples']), 10)
            self.assertEqual(len(cell['warmups']), 2)
            self.assertEqual(len({x['result_file_sha256'] for x in cell['samples']}), 1)
            self.assertEqual(cell['counters']['applied_events'], 6)
            self.assertEqual(cell['counters']['noop_events'], 2)
            self.assertTrue((out / 'event-timings.csv').exists())
            self.assertTrue((out / 'memory.csv').exists())
            # The reproducibility validator rejects insufficient/forged runs,
            # including alteration of a raw sample independently of summary.
            manifest_path = out / 'manifest.json'
            manifest = json.loads(manifest_path.read_text())
            manifest['host']['build_cache']['CMAKE_BUILD_TYPE'] = 'Release'
            manifest['host']['build_cache'].pop('CMAKE_CXX_FLAGS', None)
            manifest_path.write_text(json.dumps(manifest))
            validate_run(out, cell['id'])
            raw_path = out / cell['id'] / 'cli-000/process.json'
            raw = json.loads(raw_path.read_text())
            raw['exit_code'] = 3
            raw_path.write_text(json.dumps(raw))
            with self.assertRaises(ValueError):
                validate_run(out, cell['id'])
            with self.assertRaises(ValueError):
                execute(profile, Path(BINARY), out, allow_debug=True)

    def test_cli_dispatch_preserves_arguments(self):
        with tempfile.TemporaryDirectory(prefix='bench spaces ') as name:
            profile = Path(name) / 'profile.json'
            profile.write_text(json.dumps(PROFILE))
            result = subprocess.run([BINARY, 'bench', '--profile', str(profile), '--out', str(Path(name) / 'out'), '--allow-debug'], capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr)


if __name__ == '__main__':
    unittest.main()
