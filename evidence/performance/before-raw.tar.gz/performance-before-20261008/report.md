# Measured workload report

Core and CLI times are scenario processing, in milliseconds. RSS includes full canonical history.
macOS RSS is provisional; authoritative memory requires Linux. Expected reachability failures count as completed work.

| Cell | R/L/P | Events/assertions/destinations | Status | Core median [min,max] ms | CLI median [min,max] ms | Peak RSS median MiB |
| --- | --- | --- | --- | --- | --- | --- |
| chain-16 | 16/15/2 | 8/1/1 | complete | 0.134 [0.133,0.135] | 5.543 [5.339,5.707] | 3.73 |
| chain-64 | 64/63/2 | 8/1/1 | complete | 1.153 [1.075,1.265] | 13.586 [13.424,13.816] | 6.52 |
| chain-256 | 256/255/2 | 8/1/1 | complete | 17.396 [15.809,17.820] | 57.964 [56.199,59.517] | 17.55 |
| chain-1024 | 1024/1023/2 | 8/1/1 | budget_skipped | — | — | — |
| ring-16 | 16/16/2 | 8/1/1 | complete | 0.143 [0.139,0.149] | 6.147 [5.816,6.468] | 3.73 |
| grid-16 | 16/23/2 | 8/1/1 | complete | 0.224 [0.220,0.226] | 6.399 [6.171,6.562] | 3.97 |
| diamond-width-2 | 16/19/2 | 8/1/1 | complete | 0.188 [0.182,0.203] | 6.272 [5.895,6.464] | 3.91 |
| diamond-width-4 | 16/21/2 | 8/1/1 | complete | 0.219 [0.202,0.236] | 6.253 [6.064,6.428] | 3.97 |
| sparse-16 | 16/30/2 | 8/1/1 | complete | 0.232 [0.222,0.269] | 6.120 [5.925,6.239] | 3.95 |
| sparse-denser-16 | 16/45/2 | 8/1/1 | complete | 0.306 [0.291,0.331] | 7.049 [6.920,7.126] | 4.20 |
| ring-prefix-density-1 | 16/16/16 | 8/1/1 | complete | 0.259 [0.252,0.272] | 23.673 [23.326,24.568] | 10.41 |
| ring-prefix-density-2 | 16/16/32 | 8/2/2 | complete | 0.332 [0.321,0.354] | 43.936 [43.321,44.140] | 17.78 |
| ring-all-assertions | 16/16/16 | 8/256/16 | complete | 0.578 [0.553,0.589] | 34.561 [33.659,35.340] | 15.12 |
| ring-long-trace | 16/16/2 | 32/1/1 | complete | 0.444 [0.431,0.463] | 13.492 [13.441,13.614] | 6.25 |
| ring-64 | 64/64/64 | 8/1/1 | complete | 3.254 [3.177,3.329] | 359.048 [355.664,369.051] | 103.09 |
| ring-256-dense-probe | 256/256/512 | 8/2/2 | budget_skipped | — | — | — |

Actual counters (baseline / snapshot range; logical references include shared sets):

| Cell | Route entries | Next-hop references | Applied/no-op events | Assertion evaluations | Destination analyses |
| --- | --- | --- | --- | --- | --- |
| chain-16 | 32 / [15, 32] | 30 / [14, 30] | 6/2 | 9 | 9 |
| chain-64 | 128 / [63, 128] | 126 / [62, 126] | 6/2 | 9 | 9 |
| chain-256 | 512 / [255, 512] | 510 / [254, 510] | 6/2 | 9 | 9 |
| ring-16 | 32 / [15, 32] | 30 / [14, 30] | 6/2 | 9 | 9 |
| grid-16 | 32 / [15, 32] | 46 / [21, 46] | 6/2 | 9 | 9 |
| diamond-width-2 | 32 / [15, 32] | 38 / [18, 38] | 6/2 | 9 | 9 |
| diamond-width-4 | 32 / [15, 32] | 42 / [20, 42] | 6/2 | 9 | 9 |
| sparse-16 | 32 / [15, 32] | 38 / [18, 38] | 6/2 | 9 | 9 |
| sparse-denser-16 | 32 / [15, 32] | 60 / [25, 60] | 6/2 | 9 | 9 |
| ring-prefix-density-1 | 256 / [225, 256] | 240 / [210, 240] | 6/2 | 9 | 9 |
| ring-prefix-density-2 | 512 / [450, 512] | 480 / [420, 480] | 6/2 | 18 | 18 |
| ring-all-assertions | 256 / [225, 256] | 240 / [210, 240] | 6/2 | 2304 | 144 |
| ring-long-trace | 32 / [15, 32] | 30 / [14, 30] | 24/8 | 33 | 33 |
| ring-64 | 4096 / [3969, 4096] | 4032 / [3906, 4032] | 6/2 | 9 | 9 |

chain-1024: spf_work_units=28293120 exceeds 10000000

ring-256-dense-probe: retained_route_upper_bound=1179648 exceeds 100000; output_bytes_estimate=1057277952 exceeds 50331648; rss_bytes_estimate=4296220672 exceeds 805306368
