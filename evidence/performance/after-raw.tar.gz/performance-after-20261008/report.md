# Measured workload report

Core and CLI times are scenario processing, in milliseconds. RSS includes full canonical history.
macOS RSS is provisional; authoritative memory requires Linux. Expected reachability failures count as completed work.

| Cell | R/L/P | Events/assertions/destinations | Status | Core median [min,max] ms | CLI median [min,max] ms | Peak RSS median MiB |
| --- | --- | --- | --- | --- | --- | --- |
| chain-16 | 16/15/2 | 8/1/1 | complete | 0.092 [0.091,0.105] | 5.525 [5.381,5.600] | 3.62 |
| chain-64 | 64/63/2 | 8/1/1 | complete | 0.542 [0.527,0.569] | 11.508 [11.422,11.746] | 5.55 |
| chain-256 | 256/255/2 | 8/1/1 | complete | 6.493 [6.344,9.210] | 38.865 [38.500,49.078] | 14.44 |
| chain-1024 | 1024/1023/2 | 8/1/1 | budget_skipped | — | — | — |
| ring-16 | 16/16/2 | 8/1/1 | complete | 0.093 [0.091,0.099] | 5.270 [5.008,5.659] | 3.45 |
| grid-16 | 16/23/2 | 8/1/1 | complete | 0.148 [0.144,0.157] | 5.929 [5.650,6.067] | 3.67 |
| diamond-width-2 | 16/19/2 | 8/1/1 | complete | 0.121 [0.113,0.125] | 5.861 [5.645,5.942] | 3.62 |
| diamond-width-4 | 16/21/2 | 8/1/1 | complete | 0.134 [0.131,0.137] | 5.863 [5.665,6.051] | 3.67 |
| sparse-16 | 16/30/2 | 8/1/1 | complete | 0.151 [0.149,0.164] | 5.675 [5.487,5.889] | 3.69 |
| sparse-denser-16 | 16/45/2 | 8/1/1 | complete | 0.193 [0.190,0.200] | 6.556 [6.539,6.765] | 4.16 |
| ring-prefix-density-1 | 16/16/16 | 8/1/1 | complete | 0.195 [0.178,0.198] | 18.722 [18.520,19.081] | 10.14 |
| ring-prefix-density-2 | 16/16/32 | 8/2/2 | complete | 0.249 [0.245,0.258] | 33.601 [33.424,34.237] | 16.72 |
| ring-all-assertions | 16/16/16 | 8/256/16 | complete | 0.516 [0.498,0.566] | 29.496 [29.110,30.351] | 15.98 |
| ring-long-trace | 16/16/2 | 32/1/1 | complete | 0.267 [0.258,0.271] | 11.127 [10.824,11.310] | 5.36 |
| ring-64 | 64/64/64 | 8/1/1 | complete | 2.064 [2.031,2.167] | 254.629 [250.483,256.630] | 78.81 |
| ring-256-dense-probe | 256/256/512 | 8/2/2 | budget_skipped | — | — | — |

Actual counters (baseline / snapshot range; logical references include shared sets):

| Cell | Route entries | Next-hop references | Applied/no-op events | Assertion evaluations | Destination analyses |
| --- | --- | --- | --- | --- | --- |
| chain-16 | 32 / [15, 32] | 30 / [14, 30] | 6/2 | 9 | 9 |
| chain-64 | 128 / [63, 128] | 126 / [62, 126] | 6/2 | 9 | 9 |
| chain-256 | 512 / [255, 512] | 510 / [254, 510] | 6/2 | 9 | 9 |
| ring-16 | 32 / [15, 32] | 30 / [14, 30] | 6/2 | 9 | 9 |
| grid-16 | 32 / [15, 32] | 46 / [21, 46] | 6/2 | 9 | 9 |
| diamond-width-2 | 32 / [15, 32] | 38 / [18, 38] | 6/2 | 9 | 9 |
| diamond-width-4 | 32 / [15, 32] | 42 / [20, 42] | 6/2 | 9 | 9 |
| sparse-16 | 32 / [15, 32] | 38 / [18, 38] | 6/2 | 9 | 9 |
| sparse-denser-16 | 32 / [15, 32] | 60 / [25, 60] | 6/2 | 9 | 9 |
| ring-prefix-density-1 | 256 / [225, 256] | 240 / [210, 240] | 6/2 | 9 | 9 |
| ring-prefix-density-2 | 512 / [450, 512] | 480 / [420, 480] | 6/2 | 18 | 18 |
| ring-all-assertions | 256 / [225, 256] | 240 / [210, 240] | 6/2 | 2304 | 144 |
| ring-long-trace | 32 / [15, 32] | 30 / [14, 30] | 24/8 | 33 | 33 |
| ring-64 | 4096 / [3969, 4096] | 4032 / [3906, 4032] | 6/2 | 9 | 9 |

chain-1024: spf_work_units=28293120 exceeds 10000000

ring-256-dense-probe: retained_route_upper_bound=1179648 exceeds 100000; output_bytes_estimate=1057277952 exceeds 50331648; rss_bytes_estimate=4296220672 exceeds 805306368
